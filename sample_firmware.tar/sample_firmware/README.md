# Sample firmware tree

This folder mirrors the assignment structure using directories named like .zip containers.

Scan `sample_firmware/firmware.zip` with your analyzer.
